'''
The ver1.2 is to first try the class weighting approach for WCCNet
-------------------------------------------------------
The ver1.2.1 is to:
1. Maintains training history when resuming
2. Saves optimizer state for consistent training continuation
3. Allows specifying new total epochs when resuming
4. Preserves all metrics and best model tracking
How to use:
1. Train from scratch: python WCCNet_DenseNet_train_code_mammo_1.3.2.py --epochs 100
2. Resume from checkpoint: python WCCNet_DenseNet_train_code_mammo_1.3.py --resume --epochs 100
3. Continue training from a pretrained model: python WCCNet_DenseNet_train_code_mammo_1.3.py --pretrained path/to/model.pth --epochs 100
---------------------------------------------------------
The ver1.2.2 is to: 
1. Fix torch.load issue
-----------------------------------------------------------
The ver1.3 is to: 
1. Add (1) aggressive FlocalLoss and (2) medical imaging-specific data augmentation modified to DenseNet
2. Yet to implement: (1) train dataset split for train and val, and (2) find_optimal_threshold
3. Still using manual Learn Rate
4. How to adjust FocalLoss poarameters:
    * gamma_pos = 0.1 (reduced from 0.2) Further reduces the focus on positive (Abnormal) samples
Makes the loss less sensitive to positive class errors
    * gamma_neg = 4.0 (increased from 2.0) Significantly increases focus on negative (Normal) samples
Makes the model pay more attention to misclassified normal cases
    * alpha = 0.25 (reduced from 0.4) Gives more weight to negative cases (1 - alpha = 0.75)
Helps balance the class importance
    * pos_weight = 0.5 (reduced from 1.0) Reduces the importance of positive class
Helps prevent overemphasis on abnormal cases
    * Added neg_weight = 2.0 (new parameter) Explicitly increases the importance of negative class
Helps the model focus more on normal cases
--------------------------------------------------------------
The ver1.3.1 is to:
1. Loss Function and Weighting Changes:
    * Increased positive class weight (pos_weight=3.0)
    * Modified focal loss parameters to focus more on positive cases
    * Adjusted alpha and gamma values for better sensitivity
2. Training Process Modifications:
    * Added learning rate scheduler based on sensitivity
    * Implemented early stopping based on sensitivity
    * Enhanced model saving criteria to focus on sensitivity 
----------------------------------------------------------------
The ver1.3.2 is to:
1. Added mixed precision training for memory efficiency
2. Optimized memory usage and GPU utilization
3. Enhanced gradient checkpointing
4. Improved data loading efficiency
5. Modified class weights and focal loss parameters
6. Added TF32 support for RTX 4090
How to use:
1. Train from scratch: python WCCNet_DenseNet_train_code_mammo_1.3.2.py --epochs 100
2. Resume from checkpoint: python WCCNet_DenseNet_train_code_mammo_1.3.2.py --resume --epochs 100
3. Continue training from a pretrained model: python WCCNet_DenseNet_train_code_mammo_1.3.2.py --pretrained path/to/model.pth --epochs 100
-----------------------------------------------------------------
The ver1.3.2.1 is to:
1. Added gradient clipping
2. adjust FocalLoss abd class weights
-----------------------------------------------------------------
The ver1.3.3 is to:
1. Enhanced FocalLoss Parameters:
    * Phase 1 (First 20 epochs):
        - gamma_pos=0.5 (more focus on all positive samples)
        - gamma_neg=3.0 (less focus on negative samples)
        - alpha=0.75 (heavy positive class weight)
        - pos_weight=3.0 (strong positive emphasis)
    * Phase 2 (After 20 epochs):
        - gamma_pos=1.0 (balanced positive focus)
        - gamma_neg=2.0 (moderate negative focus)
        - alpha=0.6 (moderate positive weight)
        - pos_weight=2.0 (maintained positive emphasis)
2. Added Curriculum Learning:
    * Gradually increases abnormal class weight from 2.0 to 3.5
    * Helps prevent sudden drops in sensitivity
3. Added Sensitivity Loss Component:
    * Additional loss term specifically targeting sensitivity
    * Different weights for each training phase
4. Dynamic Training Adjustments:
    * Monitors sensitivity drops
    * Automatically adjusts alpha and pos_weight if sensitivity decreases
    * Reduces learning rate when sensitivity drops
5.  Add proper train/validation split
6.  Implement advanced learning rate scheduling
'''
import os
import torch
import torch.nn as nn
import torch.optim as optim
import copy
from torch.amp import autocast, GradScaler
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms, models
import pandas as pd
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix
from tqdm import tqdm
import time
import argparse
import warnings
warnings.filterwarnings("ignore", category=UserWarning)
import torch.nn.utils as utils
from sklearn.model_selection import train_test_split
from torch.optim.lr_scheduler import OneCycleLR, ReduceLROnPlateau

# Constants with optimized settings
TRAIN_PATH = r"D:/VinDr-Mammo/combined_dataset/train"
VAL_PATH = r"D:/VinDr-Mammo/combined_dataset/val"
TEST_PATH = r"D:/VinDr-Mammo/combined_dataset/test"
SAVE_PATH = r"D:/VinDr-Mammo/combined_dataset/saved_models_2"
# TRAIN_PATH = r"D:\VinDr_INbreast_2in1\Train"
# TEST_PATH = r"D:\VinDr_INbreast_2in1\Test"
# SAVE_PATH = r"D:\VinDr_INbreast_2in1\saved_models_16.6"
IMAGE_SIZE = 1024
BATCH_SIZE = 12  # Start with 12, can try 16 if memory allows
NUM_EPOCHS = 50
LEARNING_RATE = 1e-4
NUM_WORKERS = 8  # Increased for RTX 4090

# Enable TF32 for RTX 4090
torch.backends.cuda.matmul.allow_tf32 = True
torch.backends.cudnn.allow_tf32 = True
torch.backends.cudnn.benchmark = True

#=========================================================
class MammogramDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.root_dir = root_dir
        self.transform = transform
        self.classes = ['Normal', 'Abnormal']
        self.images = []
        self.labels = []
        
        for class_idx, class_name in enumerate(self.classes):
            class_path = os.path.join(root_dir, class_name)
            for img_name in os.listdir(class_path):
                if img_name.endswith('.png'):
                    self.images.append(os.path.join(class_path, img_name))
                    self.labels.append(class_idx)

    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        img_path = self.images[idx]
        image = Image.open(img_path).convert('L')
        image = image.resize((IMAGE_SIZE, IMAGE_SIZE), Image.Resampling.LANCZOS)
        image_np = np.array(image)
        image_rgb = np.stack([image_np] * 3, axis=-1)
        image = Image.fromarray(image_rgb.astype(np.uint8))
        label = self.labels[idx]

        if self.transform:
            image = self.transform(image)

        return image, label

#=============================================================
class WCCNet(nn.Module):
    def __init__(self, num_classes=2):
        super(WCCNet, self).__init__()
        self.densenet = models.densenet121(weights=None)
        
        # Enable gradient checkpointing for memory efficiency
        self.densenet.features.requires_grad_(True)
        self.densenet.features.gradient_checkpointing = True
        
        num_features = self.densenet.classifier.in_features
        self.densenet.classifier = nn.Sequential(
            nn.Linear(num_features, 512),
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, num_classes)
        )
        
        self.attention = nn.Sequential(
            nn.Conv2d(1024, 512, kernel_size=1),
            nn.ReLU(),
            nn.Conv2d(512, 1, kernel_size=1),
            nn.Sigmoid()
        )

    def forward(self, x):
        features = self.densenet.features(x)
        att_map = self.attention(features)
        features = features * att_map
        out = nn.functional.adaptive_avg_pool2d(features, (1, 1))
        out = torch.flatten(out, 1)
        out = self.densenet.classifier(out)
        return out, att_map

#=============================================================
class CurriculumLossWeights:
    def __init__(self, start_epoch, end_epoch, start_weight, end_weight):
        self.start_epoch = start_epoch
        self.end_epoch = end_epoch
        self.start_weight = start_weight
        self.end_weight = end_weight
        
    def get_weights(self, epoch):
        if epoch < self.start_epoch:
            return self.start_weight
        if epoch > self.end_epoch:
            return self.end_weight
        
        progress = (epoch - self.start_epoch) / (self.end_epoch - self.start_epoch)
        return self.start_weight + (self.end_weight - self.start_weight) * progress

#=============================================================
class SensitivityLoss(nn.Module):
    def __init__(self, base_criterion, sensitivity_weight=0.3):
        super().__init__()
        self.base_criterion = base_criterion
        self.sensitivity_weight = sensitivity_weight
        
    def forward(self, outputs, targets):
        base_loss = self.base_criterion(outputs, targets)
        
        # Calculate sensitivity component
        probs = torch.softmax(outputs, dim=1)
        positive_preds = probs[:, 1]  # Probability of abnormal class
        positive_mask = (targets == 1)
        
        if positive_mask.sum() > 0:
            sensitivity_loss = -torch.log(positive_preds[positive_mask]).mean()
            return base_loss + self.sensitivity_weight * sensitivity_loss
        return base_loss

#=============================================================    
class AggressiveFocalLoss(nn.Module):
    def __init__(self, weight=None, gamma_pos=0.5, gamma_neg=3.0, alpha=0.75, 
                 pos_weight=3.0, label_smoothing=0.05):
        super(AggressiveFocalLoss, self).__init__()
        self.gamma_pos = gamma_pos
        self.gamma_neg = gamma_neg
        self.alpha = alpha
        self.pos_weight = pos_weight
        self.weight = weight
        self.criterion = nn.CrossEntropyLoss(
            weight=weight,
            reduction='none',
            label_smoothing=label_smoothing
        )
    
    def forward(self, inputs, targets):
        ce_loss = self.criterion(inputs, targets)
        pt = torch.exp(-ce_loss)
        
        gamma_factor = torch.ones_like(targets, dtype=torch.float) * self.gamma_neg
        gamma_factor[targets == 1] = self.gamma_pos
        
        alpha_factor = torch.ones_like(targets, dtype=torch.float) * (1 - self.alpha)
        alpha_factor[targets == 1] = self.alpha
        
        pos_factor = torch.ones_like(targets, dtype=torch.float)
        pos_factor[targets == 1] = self.pos_weight
        
        focal_loss = alpha_factor * pos_factor * ((1 - pt) ** gamma_factor * ce_loss)
        return focal_loss.mean()

#==================================================================
def save_checkpoint(model, optimizer, epoch, history, filename):
    """Save checkpoint with all necessary info for resuming training"""
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'history': history
    }
    
    try:
        torch.save(checkpoint, filename)
        print(f"Checkpoint saved successfully to {filename}")
    except Exception as e:
        print(f"Error saving checkpoint: {e}")
        try:
            # Fallback to saving only model weights
            torch.save(model.state_dict(), filename)
            print("Saved model weights only as fallback")
        except Exception as e:
            print(f"Failed to save model weights: {e}")

#==================================================================
def load_checkpoint(model, optimizer, filename, device):
    """Load checkpoint and return necessary info for resuming training"""
    print("Loading checkpoint...")
    
    try:
        # Simple direct loading first
        checkpoint = torch.load(filename, map_location=device)
        
        if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
            model.load_state_dict(checkpoint['model_state_dict'])
            if 'optimizer_state_dict' in checkpoint:
                optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                # Move optimizer states to GPU if needed
                for state in optimizer.state.values():
                    for k, v in state.items():
                        if isinstance(v, torch.Tensor):
                            state[k] = v.to(device)
            
            start_epoch = checkpoint.get('epoch', 0)
            history = checkpoint.get('history', None)
        else:
            print("Loading only model weights...")
            model.load_state_dict(checkpoint)
            start_epoch = 0
            history = None
        
        model = model.to(device)
        print("Checkpoint loaded successfully.")
        return model, optimizer, start_epoch, history
        
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
        return model, optimizer, 0, None

#==================================================================
def train_model(model, dataloaders, criterion_phase1, criterion_phase2, optimizer, 
                scheduler, num_epochs, start_epoch=0, history=None):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    scaler = GradScaler('cuda')
    max_grad_norm = 0.5  # Reduced for more stable training

    best_model_wts = copy.deepcopy(model.state_dict())
     
    # Initialize curriculum learning
    curriculum = CurriculumLossWeights(
        start_epoch=0,
        end_epoch=20,
        start_weight=2.0,  # Initial weight for abnormal class
        end_weight=3.5     # Final weight for abnormal class
    )
    
    print(f"Using device: {device}")
    model = model.to(device)
    
    best_acc = 0.0 if history is None else max(history.get('val_acc', [0]))
    best_sensitivity = 0.0 if history is None else max(history.get('val_sens', [0]))
    previous_sens = 0.0
    start_time = time.time()
    
    if history is None:
        history = {
            'train_loss': [], 'train_acc': [], 'train_sens': [], 'train_spec': [],
            'val_loss': [], 'val_acc': [], 'val_sens': [], 'val_spec': []
        }

    print(f'\nStarting training from epoch {start_epoch + 1} to {num_epochs}...\n')

    train_metrics = {'sens': 0.0, 'spec': 0.0}
    val_metrics = {'sens': 0.0, 'spec': 0.0}
    
    for epoch in range(start_epoch, num_epochs):
        epoch_start_time = time.time()
        print(f'Epoch {epoch+1}/{num_epochs}')
        print('-' * 10)

        # Update class weights based on curriculum
        current_abnormal_weight = curriculum.get_weights(epoch)
        class_weights = torch.tensor([1.0, current_abnormal_weight]).to(device)
        
        # Select criterion based on training phase
        criterion = criterion_phase1 if epoch < 20 else criterion_phase2
        criterion.weight = class_weights

        for phase in ['train', 'val']:
            if phase == 'train':
                model.train()
                optimizer.zero_grad(set_to_none=True)
            else:
                model.eval()
                
            running_loss = 0.0
            all_preds = []
            all_labels = []

            with tqdm(dataloaders[phase], desc=f'{phase}', 
                     leave=False, ncols=100) as pbar:
                
                for inputs, labels in pbar:
                    inputs = inputs.to(device, non_blocking=True)
                    labels = labels.to(device, non_blocking=True)

                    if phase == 'train':
                        with autocast('cuda'):
                            outputs, _ = model(inputs)
                            loss = criterion(outputs, labels)
                        
                        scaler.scale(loss).backward()
                        scaler.unscale_(optimizer)
                        utils.clip_grad_norm_(model.parameters(), max_grad_norm)
                        scaler.step(optimizer)
                        scaler.update()
                        optimizer.zero_grad(set_to_none=True)
                    else:
                        with torch.no_grad():
                            outputs, _ = model(inputs)
                            loss = criterion(outputs, labels)

                    running_loss += loss.item() * inputs.size(0)
                    _, preds = torch.max(outputs, 1)
                    all_preds.extend(preds.cpu().numpy())
                    all_labels.extend(labels.cpu().numpy())
                    
                    pbar.set_postfix({'loss': f'{loss.item():.4f}'})

            # Calculate metrics
            epoch_loss = running_loss / len(dataloaders[phase].dataset)
            cm = confusion_matrix(all_labels, all_preds)
            
            tn, fp, fn, tp = cm.ravel()
            epoch_acc = (tp + tn) / (tp + tn + fp + fn)
            epoch_sens = tp / (tp + fn) if (tp + fn) > 0 else 0
            epoch_spec = tn / (tn + fp) if (tn + fp) > 0 else 0

            # Store metrics
            if phase == 'train':
                train_metrics['sens'] = epoch_sens
                train_metrics['spec'] = epoch_spec
            else:
                val_metrics['sens'] = epoch_sens
                val_metrics['spec'] = epoch_spec

                # Print Print metrics for both phases
                print(f"train Sensitivity: {train_metrics['sens']:.4f} Specificity: {train_metrics['spec']:.4f}")
                print(f"val Sensitivity: {val_metrics['sens']:.4f} Specificity: {val_metrics['spec']:.4f}")

                # Print confusion matrix 
                print("\nValidation Set Confusion Matrix:")
                print("                       Predicted Abnormal        Predicted Normal")
                print(f"Actually Abnormal           {tp:3d} (TP)               {fn:3d} (FN)")
                print(f"Actually Normal             {fp:3d} (FP)              {tn:4d} (TN)\n")

            # Update history
            history[f'{phase}_loss'].append(epoch_loss)
            history[f'{phase}_acc'].append(epoch_acc)
            history[f'{phase}_sens'].append(epoch_sens)
            history[f'{phase}_spec'].append(epoch_spec)

            if phase == 'val':
                # Check if sensitivity dropped
                if epoch_sens < previous_sens and epoch > 10:
                    # Adjust the base criterion parameters
                    if hasattr(criterion, 'base_criterion'):
                        criterion.base_criterion.alpha = min(0.85, criterion.base_criterion.alpha * 1.1)
                        criterion.base_criterion.pos_weight = min(4.0, criterion.base_criterion.pos_weight * 1.1)
                    
                    # Reduce learning rate
                    for param_group in optimizer.param_groups:
                        param_group['lr'] *= 0.8
                
                previous_sens = epoch_sens
                scheduler.step_plateau(epoch_sens)  # Use sensitivity for scheduler
        
                total_score = epoch_sens + epoch_spec
                
                # Save best accuracy model
                if epoch_acc > best_acc:
                    best_acc = epoch_acc
                    model_name = f'best_accuracy_model_Acc{epoch_acc*100:.2f}_Sen{epoch_sens*100:.2f}_Spe{epoch_spec*100:.2f}_Score{total_score*100:.0f}_{epoch+1}E.pth'
                    torch.save(model.state_dict(), os.path.join(SAVE_PATH, model_name))
                    print(f"Saved new best accuracy model: {model_name}")

                if epoch_sens > 0.70 and epoch_spec > 0.70:
                    model_name = f'best_balanced_model_Acc{epoch_acc*100:.2f}_Sen{epoch_sens*100:.2f}_Spe{epoch_spec*100:.2f}_Score{total_score*100:.0f}_{epoch+1}E.pth'
                    model_path = os.path.join(SAVE_PATH, model_name)
                    torch.save(model.state_dict(), model_path)
                    print(f"Saved new best balanced model: {model_name}")
                    print(f"New best sum of Sen + Spe: {total_score*100:.2f}")

        # Clear cache between epochs
        torch.cuda.empty_cache()
        
        # Save checkpoint after each epoch
        checkpoint_path = os.path.join(SAVE_PATH, 'checkpoint.pth')
        save_checkpoint(model, optimizer, epoch + 1, history, checkpoint_path)

        train_loss = history['train_loss'][-1]
        train_acc = history['train_acc'][-1]
        val_loss = history['val_loss'][-1]
        val_acc = history['val_acc'][-1]
        
        # Calculate epoch time
        epoch_time = time.time() - epoch_start_time
        epoch_hours = int(epoch_time // 3600)
        epoch_minutes = int((epoch_time % 3600) // 60)
        epoch_seconds = int(epoch_time % 60)
        
        # Calculate total elapsed time
        total_time = time.time() - start_time
        total_hours = int(total_time // 3600)
        total_minutes = int((total_time % 3600) // 60)
        total_seconds = int(total_time % 60)
        
        print('=' * 114)
        print(f'Epoch [{epoch+1}/{num_epochs}]: Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.4f} | '
              f'Val Loss: {val_loss:.4f} | Val Acc: {val_acc:.4f} | '
              f'Time: {epoch_hours}:{epoch_minutes:02d}:{epoch_seconds:02d}/{total_hours}:{total_minutes:02d}:{total_seconds:02d}')
        print('=' * 114)
        print()

    final_model_name = f'final_model_Acc{val_acc*100:.2f}_Sen{history["val_sens"][-1]*100:.2f}_Spe{history["val_spec"][-1]*100:.2f}_Score{total_score*100:.0f}_{num_epochs}E.pth'
    torch.save(model.state_dict(), os.path.join(SAVE_PATH, final_model_name))
    print(f"\nSaved final model: {final_model_name}")
    
    model.load_state_dict(best_model_wts)
    
    return model, history

#==================================================================
def print_dataset_summary(train_dataset, val_dataset, test_dataset):
    # Get counts for training set
    if isinstance(train_dataset, torch.utils.data.Subset):
        train_labels = [train_dataset.dataset.labels[i] for i in train_dataset.indices]
    else:
        train_labels = train_dataset.labels
    train_unique, train_counts = np.unique(train_labels, return_counts=True)
    
    # Get counts for validation set
    if isinstance(val_dataset, torch.utils.data.Subset):
        val_labels = [val_dataset.dataset.labels[i] for i in val_dataset.indices]
    else:
        val_labels = val_dataset.labels
    val_unique, val_counts = np.unique(val_labels, return_counts=True)
    
    # Get counts for test set
    test_labels = test_dataset.labels
    test_unique, test_counts = np.unique(test_labels, return_counts=True)
    
    print("\nDataset Summary:")
    print("Training set:")
    print(f"  Normal: {train_counts[0]} images")
    print(f"  Abnormal: {train_counts[1]} images")
    print(f"  Total: {sum(train_counts)} images")
    
    print("\nValidation set:")
    print(f"  Normal: {val_counts[0]} images")
    print(f"  Abnormal: {val_counts[1]} images")
    print(f"  Total: {sum(val_counts)} images")
    
    print("\nTest set:")
    print(f"  Normal: {test_counts[0]} images")
    print(f"  Abnormal: {test_counts[1]} images")
    print(f"  Total: {sum(test_counts)} images")

    print(f"\nSaved Path: {SAVE_PATH}")

#==================================================================
# Add this function to evaluate the model on test set after training
def evaluate_test_set(model, test_dataloader, criterion, device):
    model.eval()
    running_loss = 0.0
    all_preds = []
    all_labels = []
    
    with torch.no_grad():
        for inputs, labels in tqdm(test_dataloader, desc='Test Evaluation'):
            inputs = inputs.to(device, non_blocking=True)
            labels = labels.to(device, non_blocking=True)
            
            outputs, _ = model(inputs)
            loss = criterion(outputs, labels)
            
            running_loss += loss.item() * inputs.size(0)
            _, preds = torch.max(outputs, 1)
            all_preds.extend(preds.cpu().numpy())
            all_labels.extend(labels.cpu().numpy())
    
    # Calculate metrics
    test_loss = running_loss / len(test_dataloader.dataset)
    cm = confusion_matrix(all_labels, all_preds)
    tn, fp, fn, tp = cm.ravel()
    
    test_acc = (tp + tn) / (tp + tn + fp + fn)
    test_sens = tp / (tp + fn) if (tp + fn) > 0 else 0
    test_spec = tn / (tn + fp) if (tn + fp) > 0 else 0
    
    return {
        'loss': test_loss,
        'accuracy': test_acc,
        'sensitivity': test_sens,
        'specificity': test_spec,
        'confusion_matrix': cm
    }

#==================================================================
def plot_training_results(history, total_epochs):
    epochs = range(1, len(history['train_loss']) + 1)
    
    plt.figure(figsize=(12, 8))
    
    plt.plot(epochs, history['val_acc'], 'r-', label='Accuracy', linewidth=2)
    plt.plot(epochs, history['val_sens'], 'g-', label='Sensitivity', linewidth=2)
    plt.plot(epochs, history['val_spec'], 'y-', label='Specificity', linewidth=2)
    
    plt.title('Training Progress', fontsize=14, pad=15)
    plt.xlabel('Epochs', fontsize=12)
    plt.ylabel('Metrics', fontsize=12)
    plt.grid(True, linestyle='--', alpha=0.7)
    plt.legend(loc='center right', bbox_to_anchor=(1.25, 0.5), fontsize=10)
    
    plt.tight_layout()
    plt.savefig(os.path.join(SAVE_PATH, f'training_results_{total_epochs}E.png'), bbox_inches='tight')
    plt.close()

#==================================================================
def main():
    parser = argparse.ArgumentParser(description='Train WCCNet with resume capability')
    parser.add_argument('--resume', action='store_true', help='Resume training from checkpoint')
    parser.add_argument('--pretrained', type=str, help='Path to pretrained model to continue training')
    parser.add_argument('--epochs', type=int, default=NUM_EPOCHS, help='Number of epochs to train')
    args = parser.parse_args()

    os.makedirs(SAVE_PATH, exist_ok=True)
    print("Preparing datasets and model...")

    # Enhanced data augmentation with medical imaging-specific transforms
    train_transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE), interpolation=transforms.InterpolationMode.LANCZOS),
        transforms.RandomAffine(
            degrees=15,
            translate=(0.1, 0.1),
            scale=(0.85, 1.15),
            fill=0,
            interpolation=transforms.InterpolationMode.BILINEAR
        ),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.ColorJitter(
            brightness=0.2,
            contrast=0.2
        ),
        transforms.RandomApply([
            transforms.GaussianBlur(kernel_size=3, sigma=(0.1, 0.2))
        ], p=0.3),
        transforms.ToTensor(),
        transforms.RandomErasing(p=0.1, scale=(0.02, 0.1)),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    val_transform = transforms.Compose([
        transforms.Grayscale(num_output_channels=3),
        transforms.Resize((IMAGE_SIZE, IMAGE_SIZE), interpolation=transforms.InterpolationMode.LANCZOS),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])
    ])
    
    # Enable TF32 for RTX 4090
    torch.backends.cuda.matmul.allow_tf32 = True
    torch.backends.cudnn.allow_tf32 = True
    torch.backends.cudnn.benchmark = True
    
    # Create full training dataset
    full_train_dataset = MammogramDataset(TRAIN_PATH, transform=train_transform)
    test_dataset = MammogramDataset(TEST_PATH, transform=val_transform)
    
    # Split training data into train and validation sets
    train_indices, val_indices = train_test_split(
        range(len(full_train_dataset)),
        test_size=0.15,  # 15% for validation
        stratify=full_train_dataset.labels,
        random_state=42
    )
    
    # Create train and validation datasets using subset
    train_dataset = torch.utils.data.Subset(full_train_dataset, train_indices)
    val_dataset = torch.utils.data.Subset(
        MammogramDataset(TRAIN_PATH, transform=val_transform),  # Use val_transform for validation set
        val_indices
    )
    
    # Print dataset summary after creating datasets
    print_dataset_summary(train_dataset, val_dataset, test_dataset)

    # Adjusted class weights for better sensitivity
    weight_normal = 1.0
    weight_abnormal = 1.2 # was 2.5

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    class_weights = torch.tensor([weight_normal, weight_abnormal]).to(device)
    print(f"\nUsing class weights: Normal = {weight_normal:.4f}, Abnormal = {weight_abnormal:.4f}")
    
    # DataLoaders for all three sets
    dataloaders = {
        'train': DataLoader(
            train_dataset,
            batch_size=BATCH_SIZE,
            shuffle=True,
            num_workers=NUM_WORKERS,
            pin_memory=True,
            persistent_workers=True,
            prefetch_factor=2
        ),
        'val': DataLoader(
            val_dataset,
            batch_size=BATCH_SIZE,
            shuffle=False,
            num_workers=NUM_WORKERS,
            pin_memory=True,
            persistent_workers=True
        ),
        'test': DataLoader(
            test_dataset,
            batch_size=BATCH_SIZE,
            shuffle=False,
            num_workers=NUM_WORKERS,
            pin_memory=True,
            persistent_workers=True
        )
    }
    
    # Create base focal loss for each phase
    base_criterion_phase1 = AggressiveFocalLoss(
        weight=class_weights,
        gamma_pos=1.2, # was 0.5, 1.0
        gamma_neg=1.8, # was 3.0, 2.0
        alpha=0.55, # was 0.75, 0.6
        pos_weight=1.5, # was 3.0, 2.0
        label_smoothing=0.05
    )

    base_criterion_phase2 = AggressiveFocalLoss(
        weight=class_weights,
        gamma_pos=1.5, # was 1.0
        gamma_neg=1.5, # was 2.0
        alpha=0.5, # was 0.6
        pos_weight=1.2, # was 2.0, 1.5
        label_smoothing=0.05
    )

    # Wrap with sensitivity loss
    criterion_phase1 = SensitivityLoss(base_criterion_phase1, sensitivity_weight=0.3)
    criterion_phase2 = SensitivityLoss(base_criterion_phase2, sensitivity_weight=0.2)

    model = WCCNet(num_classes=2)
    
    # Optimizer with weight decay
    optimizer = optim.AdamW(
        model.parameters(),
        lr=LEARNING_RATE,
        weight_decay=0.01
    )
    
    # Advanced Learning Rate Scheduling
    # 1. OneCycleLR for training phase
    steps_per_epoch = len(dataloaders['train'])
    total_steps = steps_per_epoch * args.epochs
    
    one_cycle_scheduler = OneCycleLR(
        optimizer,
        max_lr=LEARNING_RATE,
        total_steps=total_steps,
        pct_start=0.1,  # 10% warmup
        div_factor=10,  # initial_lr = max_lr/10
        final_div_factor=1000,  # final_lr = initial_lr/1000
        anneal_strategy='cos'
    )
    
    # 2. ReduceLROnPlateau for sensitivity-based adjustment
    plateau_scheduler = ReduceLROnPlateau(
        optimizer,
        mode='max',
        factor=0.8, # was 0.5
        patience=4, # was 3
        verbose=True,
        min_lr=1e-6
    )
    
    # Create a composite scheduler class to manage both schedulers
    class CompositeScheduler:
        def __init__(self, one_cycle_scheduler, plateau_scheduler):
            self.one_cycle_scheduler = one_cycle_scheduler
            self.plateau_scheduler = plateau_scheduler
        
        def step(self, metrics=None):
            # OneCycleLR updates every batch
            self.one_cycle_scheduler.step()
        
        def step_plateau(self, metrics):
            # ReduceLROnPlateau updates based on validation metrics
            self.plateau_scheduler.step(metrics)
    
    scheduler = CompositeScheduler(one_cycle_scheduler, plateau_scheduler)
    
    start_epoch = 0
    history = None

    # Move model to device
    model = model.to(device)
    
    if args.resume:
        checkpoint_path = os.path.join(SAVE_PATH, 'checkpoint.pth')
        if os.path.exists(checkpoint_path):
            print(f"Resuming training from checkpoint: {checkpoint_path}")
            model, optimizer, start_epoch, history = load_checkpoint(model, optimizer, checkpoint_path, device)
        else:
            print("No checkpoint found. Starting from beginning.")
    elif args.pretrained:
        if os.path.exists(args.pretrained):
            print(f"Loading pretrained model: {args.pretrained}")
            checkpoint = torch.load(args.pretrained, map_location=device)
            
            if isinstance(checkpoint, dict) and 'model_state_dict' in checkpoint:
                model.load_state_dict(checkpoint['model_state_dict'])
                if 'optimizer_state_dict' in checkpoint:
                    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                if 'epoch' in checkpoint:
                    start_epoch = checkpoint['epoch']
                if 'history' in checkpoint:
                    history = checkpoint['history']
            else:
                model.load_state_dict(checkpoint)
            
            model = model.to(device)
        else:
            print(f"Pretrained model not found: {args.pretrained}")
            return
    
    # Enable gradient checkpointing for memory efficiency
    model.densenet.features.requires_grad_(True)
    model.densenet.features.gradient_checkpointing = True
    
    # Train model with all optimizations
    model, history = train_model(
        model, 
        {'train': dataloaders['train'], 'val': dataloaders['val']},  # Only pass train and val
        criterion_phase1,
        criterion_phase2,
        optimizer, 
        scheduler, 
        args.epochs, 
        start_epoch, 
        history
    )
    
    # After training, evaluate on test set
    print("\nFinal Evaluation on Test Set:")
    print("-" * 30)
    test_results = evaluate_test_set(model, dataloaders['test'], criterion_phase2, device)
    
    print("\nTest Set Results:")
    print(f"Test Accuracy: {test_results['accuracy']*100:.2f}%")
    print(f"Test Sensitivity: {test_results['sensitivity']*100:.2f}%")
    print(f"Test Specificity: {test_results['specificity']*100:.2f}%")
    
    print("\nTest Set Confusion Matrix:")
    cm = test_results['confusion_matrix']
    print("                       Predicted Abnormal        Predicted Normal         Total")
    print(f"Actually Abnormal           {cm[1,1]:3d} (TP)               {cm[1,0]:3d} (FN)             {cm[1,0]+cm[1,1]:4d}")
    print(f"Actually Normal             {cm[0,1]:3d} (FP)              {cm[0,0]:4d} (TN)             {cm[0,0]+cm[0,1]:4d}")
    total_predicted_abn = cm[1,1] + cm[0,1]
    total_predicted_normal = cm[1,0] + cm[0,0]
    print(f"Total                       {total_predicted_abn:3d}                    {total_predicted_normal:3d}                    {cm.sum():4d}")
   
    # Save test results
    test_results_file = os.path.join(SAVE_PATH, f'test_results_{args.epochs}E.txt')
    with open(test_results_file, 'w') as f:
        f.write(f"Test Set Results:\n")
        f.write(f"Loss: {test_results['loss']:.4f}\n")
        f.write(f"Accuracy: {test_results['accuracy']*100:.2f}%\n")
        f.write(f"Sensitivity: {test_results['sensitivity']*100:.2f}%\n")
        f.write(f"Specificity: {test_results['specificity']*100:.2f}%\n")
        f.write(f"\nConfusion Matrix:\n")
        f.write(f"{test_results['confusion_matrix']}")

    plot_training_results(history, args.epochs)

if __name__ == "__main__":
    main()